/*
 *  NoiseData.cpp
 *  WhiteNoiseStimulusPlugin
 *
 *  Created by romesh kumbhani on 2015-10-07.
 *  Copyright 2015 nyu. All rights reserved.
 *
 */



#include "NoiseData.h"
#include "Utilities.h"

#include <algorithm>

using namespace mw;

NoiseData::NoiseData(string distribution, uint _nsubchecks_x, uint _nsubchecks_y, uint nchecks_x, uint nchecks_y, uint seed, float _dmu, float _drange) {
    //data_size = std::max(2u, Utilities::getNextPowerOfTwo());

    ntotalcols = _nsubchecks_x * nchecks_x;
    ntotalrows = _nsubchecks_y * nchecks_y;
    nsubchecks_x = _nsubchecks_x;
    nsubchecks_y = _nsubchecks_y;
    data = new GLfloat[ntotalrows * ntotalcols * M_MASK_CHANNELS];
    dtype = distribution;
    dmu = _dmu;
    drange = _drange;
    srand(seed);
    genNewData();
    
}

NoiseData::~NoiseData() {
	delete [] data;
}


void NoiseData::genNewData(){
    
    for(uint r=0; r<ntotalrows; r += nsubchecks_y) {
        for(uint c=0; c<ntotalcols; c += nsubchecks_x) {
            GLfloat val = getRandVal();
            uint basendx = (r*ntotalcols + c);
            for(uint sr=0; sr<nsubchecks_y; ++sr) {
                for(uint sc=0; sc<nsubchecks_x; ++sc) {
                    for(unsigned int channel=0; channel<M_MASK_CHANNELS; ++channel) {
                        data[(basendx + (sr*ntotalcols) + sc)*M_MASK_CHANNELS+channel] = val;
                    }
                }
            }
        }
    }
}


const GLfloat * NoiseData::getData() const {
	return data;
}

unsigned int NoiseData::getSizeW() const {
    return ntotalcols;
}
unsigned int NoiseData::getSizeH() const {
    return ntotalrows;
}

const std::string NoiseData::getName() const {
    return dtype;
}

GLfloat NoiseData::getRandVal(){
    double rval = 0.5;
    if (dtype == "ternary"){
        rval = (double)((rand() % 3) / 2.0);
    }
    if (dtype == "binary"){
        rval = (double)(rand() % 2);
    }
    if (dtype == "gaussian"){
        double U, V;
        U = rand()/RAND_MAX;
        V = rand()/RAND_MAX;
        
        rval = (double)((sqrt(-2 * log(U)) * sin(2.0 * M_PI * V))*(drange/6.0)+((dmu+1.0)/2.0));
    }
    rval = (std::min(1.0,std::max(0.0,rval)));
    return (GLfloat)rval;
}