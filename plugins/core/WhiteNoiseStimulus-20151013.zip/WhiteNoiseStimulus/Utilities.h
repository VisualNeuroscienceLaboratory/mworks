/*
 *  Utilities.h
 *  StimulusPlugin
 *
 *  Created by bkennedy on 11/13/08.
 *  Copyright 2008 mit. All rights reserved.
 *
 */

#ifndef UTILITIES_H
#define UTILITIES_H

class Utilities {
public:
	static unsigned int getNextPowerOfTwo(unsigned int number);
};

#endif
