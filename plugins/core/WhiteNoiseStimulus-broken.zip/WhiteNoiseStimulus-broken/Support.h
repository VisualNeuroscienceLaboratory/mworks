/*
 *  Support.h
 *  Support Functions
 *
 *  Created by Romesh Kumbhani on 10/6/15
 *  Copyright 2015 nyu. All rights reserved.
 *
 */

#ifndef SUPPORT_H
#define SUPPORT_H

class Support {
public:
	static unsigned int getNextPowerOfTwo(unsigned int number);
};

#endif
