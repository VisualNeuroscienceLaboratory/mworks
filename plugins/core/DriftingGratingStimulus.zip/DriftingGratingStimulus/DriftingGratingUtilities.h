/*
 *  DriftingGratingUtilities.h
 *  DriftingGratingStimulusPlugin
 *
 *  Created by bkennedy on 11/13/08.
 *  Copyright 2008 mit. All rights reserved.
 *
 */

#ifndef DRIFTING_GRATING_UTILITIES_H
#define DRIFTING_GRATING_UTILITIES_H

class DriftingGratingUtilities {
public:
	static unsigned int getNextPowerOfTwo(unsigned int number);
};

#endif
